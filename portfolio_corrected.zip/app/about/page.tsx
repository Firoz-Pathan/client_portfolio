import { Navigation } from "@/components/navigation"
import { About } from "@/components/about"
import { Footer } from "@/components/footer"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-[#0A0F17] text-white">
      <Navigation />
      <div className="pt-16">
        <About />
      </div>
      <Footer />
    </main>
  )
}

