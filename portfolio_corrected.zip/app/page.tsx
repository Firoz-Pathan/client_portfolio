import { Navigation } from "@/components/navigation"
import { About } from "@/components/about"
import { Hero } from "@/components/hero"
import { Services } from "@/components/services"
import { Projects } from "@/components/projects"
import { Testimonials } from "@/components/testimonials"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#0A0F17] text-white">
      <Navigation />
      <div className="pt-16">
        {" "}
        {/* Add padding to account for fixed navbar */}
        <About />
        <Hero />
        <Services />
        <Projects />
        <Testimonials />
        <Contact />
      </div>
      <Footer />
    </main>
  )
}

