import { Navigation } from "@/components/navigation"
import { Projects } from "@/components/projects"
import { Footer } from "@/components/footer"

export default function ProjectsPage() {
  return (
    <main className="min-h-screen bg-[#0A0F17] text-white">
      <Navigation />
      <div className="pt-16">
        <Projects />
      </div>
      <Footer />
    </main>
  )
}

