import { Navigation } from "@/components/navigation"
import { Services } from "@/components/services"
import { Footer } from "@/components/footer"

export default function ServicesPage() {
  return (
    <main className="min-h-screen bg-[#0A0F17] text-white">
      <Navigation />
      <div className="pt-16">
        <Services />
      </div>
      <Footer />
    </main>
  )
}

