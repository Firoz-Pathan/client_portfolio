import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Download, Briefcase, Users, Award, Coffee } from "lucide-react"

export function About() {
  return (
    <section className="px-4 py-16" id="about">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-sm text-green-400 uppercase tracking-wider mb-4">About Me</h2>
            <h3 className="text-3xl md:text-4xl font-bold mb-6">Know Who I Am</h3>
            <div className="prose prose-invert max-w-none">
              <p className="text-white/80 mb-6">
                I'm a full-stack developer with 5+ years of experience building web applications. Specialized in React,
                Next.js, Node.js, and modern web technologies.
              </p>
              <p className="text-white/80 mb-6">
                Previously worked with startups and scale-ups, helping them build and scale their web applications.
                Currently focused on creating performant and accessible web experiences.
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <Link href="/resume.pdf" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-500/10">
                  <Download className="mr-2 h-4 w-4" />
                  Download Resume
                </Button>
              </Link>
              <Link href="/projects">
                <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-500/10">
                  View Projects <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative h-[400px] md:h-[500px]">
            <Image
              src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80"
              alt="Developer portrait"
              fill
              className="object-cover rounded-lg"
            />
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
          <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
            <CardContent className="flex flex-col items-center p-6">
              <Briefcase className="h-8 w-8 text-green-400 mb-2" />
              <div className="text-3xl font-bold text-green-400 mb-2">5+</div>
              <div className="text-white/80 text-center">Years of Experience</div>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
            <CardContent className="flex flex-col items-center p-6">
              <Users className="h-8 w-8 text-green-400 mb-2" />
              <div className="text-3xl font-bold text-green-400 mb-2">50+</div>
              <div className="text-white/80 text-center">Projects Completed</div>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
            <CardContent className="flex flex-col items-center p-6">
              <Award className="h-8 w-8 text-green-400 mb-2" />
              <div className="text-3xl font-bold text-green-400 mb-2">30+</div>
              <div className="text-white/80 text-center">Happy Clients</div>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
            <CardContent className="flex flex-col items-center p-6">
              <Coffee className="h-8 w-8 text-green-400 mb-2" />
              <div className="text-3xl font-bold text-green-400 mb-2">∞</div>
              <div className="text-white/80 text-center">Coffee Consumed</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

