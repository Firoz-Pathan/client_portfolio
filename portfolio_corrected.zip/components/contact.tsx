"use client";

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Send } from "lucide-react"

export function Contact() {
  return (
    <section className="px-4 py-16" id="contact">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-sm text-green-400 uppercase tracking-wider mb-4">Get in Touch</h2>
          <h3 className="text-3xl md:text-4xl font-bold mb-4">Start a Project</h3>
          <p className="text-white/80">Let's discuss your next web application</p>
        </div>

        <Card className="max-w-xl mx-auto bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle>Send Message</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-white/80 mb-2 block">Name</label>
                  <Input className="bg-white/5 border-white/10 focus:border-green-500 transition-colors" />
                </div>
                <div>
                  <label className="text-sm text-white/80 mb-2 block">Email</label>
                  <Input type="email" className="bg-white/5 border-white/10 focus:border-green-500 transition-colors" />
                </div>
              </div>
              <div>
                <label className="text-sm text-white/80 mb-2 block">Message</label>
                <Textarea className="bg-white/5 border-white/10 focus:border-green-500 transition-colors" rows={6} />
              </div>
              <Button type="submit" className="w-full bg-green-500 hover:bg-green-600 transition-colors">
                <Send className="mr-2 h-4 w-4" /> Send Message
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}

