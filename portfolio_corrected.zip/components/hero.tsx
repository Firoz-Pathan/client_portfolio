import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, GitlabIcon as GitHub, Linkedin, Twitter } from "lucide-react"

export function Hero() {
  return (
    <section className="px-4 py-20 md:py-32">
      <div className="max-w-6xl mx-auto text-center">
        <div className="inline-flex items-center bg-white/10 rounded-full px-4 py-2 mb-8">
          <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
          <span className="text-sm">Available for opportunities</span>
        </div>

        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Full-Stack Developer
          <br />
          Building Digital Solutions
        </h1>

        <p className="text-lg text-white/60 mb-8 max-w-2xl mx-auto">
          Specialized in React, Next.js, and modern web development. Creating performant and scalable applications.
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
          <Link href="/contact">
            <Button size="lg" className="bg-green-500 hover:bg-green-600 transition-colors">
              Let's collaborate <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
          <Link href="/projects">
            <Button variant="outline" size="lg" className="border-green-500 text-green-500 hover:bg-green-500/10">
              View Projects
            </Button>
          </Link>
        </div>

        <div className="flex justify-center space-x-4 mb-12">
          <Link href="https://github.com" target="_blank" rel="noopener noreferrer">
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/10">
              <GitHub className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/10">
              <Linkedin className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer">
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/10">
              <Twitter className="h-5 w-5" />
            </Button>
          </Link>
        </div>

        <div className="relative h-64 md:h-96">
          <Image
            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80"
            alt="Developer workspace"
            fill
            className="object-cover rounded-lg"
          />
        </div>
      </div>
    </section>
  )
}

