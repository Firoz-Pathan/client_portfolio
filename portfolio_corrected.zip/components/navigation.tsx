"use client";

"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Menu, X, Home, Briefcase, Code, User, Mail } from "lucide-react"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  const toggleMenu = () => setIsOpen(!isOpen)

  const navItems = [
    { name: "Home", href: "/", icon: <Home className="h-4 w-4 mr-2" /> },
    { name: "Services", href: "/services", icon: <Briefcase className="h-4 w-4 mr-2" /> },
    { name: "Projects", href: "/projects", icon: <Code className="h-4 w-4 mr-2" /> },
    { name: "About", href: "/about", icon: <User className="h-4 w-4 mr-2" /> },
    { name: "Contact", href: "/contact", icon: <Mail className="h-4 w-4 mr-2" /> },
  ]

  useEffect(() => {
    // Close mobile menu when route changes
    setIsOpen(false)
  }, [])

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-white/10">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="text-xl font-bold">
            Developer
          </Link>

          <button onClick={toggleMenu} className="md:hidden p-2 text-white/60 hover:text-white">
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link key={item.name} href={item.href}>
                <Button
                  variant={pathname === item.href ? "secondary" : "ghost"}
                  className="text-sm transition-all duration-200 hover:bg-white/10"
                >
                  {item.icon}
                  {item.name}
                </Button>
              </Link>
            ))}
            <Link href="/contact">
              <Button className="bg-green-500 hover:bg-green-600 transition-colors ml-4">Let's Talk</Button>
            </Link>
          </div>
        </div>

        {isOpen && (
          <div className="md:hidden py-4">
            <div className="flex flex-col space-y-2">
              {navItems.map((item) => (
                <Link key={item.name} href={item.href}>
                  <Button
                    variant={pathname === item.href ? "secondary" : "ghost"}
                    className="w-full justify-start text-sm transition-all duration-200 hover:bg-white/10"
                  >
                    {item.icon}
                    {item.name}
                  </Button>
                </Link>
              ))}
              <Link href="/contact">
                <Button className="bg-green-500 hover:bg-green-600 transition-colors w-full mt-4">Let's Talk</Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

