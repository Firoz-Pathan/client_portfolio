import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export function Projects() {
  const projects = [
    {
      title: "E-commerce Platform",
      description: "Full-stack e-commerce solution with Next.js, Stripe, and Prisma",
      metrics: ["100k+ Monthly Active Users", "99.9% Uptime", "2.5s Average Load Time"],
      image:
        "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "AI-Powered Learning Platform",
      description: "Educational platform leveraging OpenAI's GPT for personalized learning",
      metrics: ["50k+ Students Enrolled", "95% User Satisfaction", "30% Learning Improvement"],
      image:
        "https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80",
    },
    {
      title: "Real-time Analytics Dashboard",
      description: "Data visualization platform with WebSocket and D3.js",
      metrics: ["Real-time Data Processing", "Custom Chart Components", "5ms Response Time"],
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
  ]

  return (
    <section className="px-4 py-16 bg-black/20" id="projects">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-sm text-green-400 uppercase tracking-wider mb-4">Featured Projects</h2>
          <h3 className="text-3xl md:text-4xl font-bold mb-4">Recent Development Work</h3>
          <p className="text-white/80">A selection of my recent full-stack projects</p>
        </div>

        <div className="grid gap-8">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="bg-white/5 border-white/10 hover:border-green-400/50 transition-all duration-300 hover:transform hover:-translate-y-1"
            >
              <div className="grid md:grid-cols-2 gap-8">
                <CardContent className="p-4 md:p-8">
                  <h4 className="text-xl md:text-2xl font-bold mb-4">{project.title}</h4>
                  <p className="text-white/80 mb-6">{project.description}</p>
                  <ul className="space-y-3 mb-6">
                    {project.metrics.map((metric, idx) => (
                      <li key={idx} className="flex items-center space-x-3">
                        <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                        <span className="text-white/80">{metric}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href={`/projects/${project.title.toLowerCase().replace(/\s+/g, "-")}`}>
                    <Button variant="outline" className="w-full md:w-auto hover:bg-green-500/10 transition-colors">
                      View Case Study <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </CardContent>
                <div className="relative h-[200px] md:h-auto">
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    fill
                    className="object-cover rounded-b-lg md:rounded-r-lg md:rounded-b-none"
                  />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

