import Link from "next/link"
import { Code2, Database, Layout, ArrowRight } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function Services() {
  const services = [
    {
      icon: <Layout className="h-8 w-8" />,
      title: "Frontend Development",
      description: "Building responsive and interactive user interfaces with React, Next.js, and modern CSS",
    },
    {
      icon: <Database className="h-8 w-8" />,
      title: "Backend Development",
      description: "Creating robust APIs and server-side applications with Node.js and databases",
    },
    {
      icon: <Code2 className="h-8 w-8" />,
      title: "Full-Stack Solutions",
      description: "End-to-end development of web applications with modern tech stack",
    },
  ]

  return (
    <section className="px-4 py-16" id="services">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-sm text-green-400 uppercase tracking-wider mb-4">My Services</h2>
          <h3 className="text-3xl md:text-4xl font-bold mb-4">Diverse Solutions For Modern Web</h3>
          <p className="text-white/80">Delivering high-quality development services tailored to your needs</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="bg-white/5 border-white/10 hover:border-green-400/50 transition-all duration-300 hover:transform hover:-translate-y-1"
            >
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-green-400/10 text-green-400 flex items-center justify-center mb-4">
                  {service.icon}
                </div>
                <CardTitle className="text-xl md:text-2xl">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80 mb-4">{service.description}</p>
                <Link href="/contact">
                  <Button variant="link" className="text-green-400 p-0 h-auto hover:text-green-500 transition-colors">
                    Learn More <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

