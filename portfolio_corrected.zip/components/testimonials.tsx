import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function Testimonials() {
  const testimonials = [
    {
      name: "Alex Johnson",
      role: "CTO at TechStart",
      content:
        "An exceptional developer who consistently delivers high-quality code. Their expertise in React and Next.js helped us launch our product ahead of schedule.",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    },
    {
      name: "Sarah Chen",
      role: "Product Manager",
      content:
        "Great technical skills combined with strong communication. Always provides valuable insights and solutions to complex problems.",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
    },
    {
      name: "Michael Brown",
      role: "Founder at WebFlow",
      content:
        "Delivered an outstanding web application that exceeded our expectations. Their attention to detail and problem-solving skills are impressive.",
      avatar: "https://randomuser.me/api/portraits/men/22.jpg",
    },
  ]

  return (
    <section className="px-4 py-16 bg-black/20" id="testimonials">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-sm text-green-400 uppercase tracking-wider mb-4">Testimonials</h2>
          <h3 className="text-3xl md:text-4xl font-bold mb-4">Client Feedback</h3>
          <p className="text-white/60">What people say about working with me</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="bg-white/5 border-white/10 hover:border-green-400/50 transition-all duration-300 hover:transform hover:-translate-y-1"
            >
              <CardContent className="p-6 md:p-8">
                <div className="flex items-center mb-6">
                  <Avatar className="h-12 w-12 mr-4">
                    <AvatarImage src={testimonial.avatar} />
                    <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-white/60">{testimonial.role}</div>
                  </div>
                </div>
                <p className="text-white/80">{testimonial.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

