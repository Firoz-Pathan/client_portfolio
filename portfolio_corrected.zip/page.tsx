import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export default function Page() {
  return (
    <div className="min-h-screen bg-[#0A0F17] text-white relative overflow-hidden">
      {/* Navigation */}
      <nav className="relative z-10 px-4 py-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-center">
            <div className="bg-white/10 backdrop-blur-lg rounded-full px-6 py-2">
              <ul className="flex items-center space-x-8">
                <li>
                  <Link href="#" className="text-white/90 hover:text-white">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-white/90 hover:text-white">
                    Works
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-white/90 hover:text-white">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-white/90 hover:text-white">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 px-4 py-16 text-center">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="flex justify-center mb-2">
            <div className="bg-[#1A1F2A] rounded-full p-4 inline-flex">
              <span role="img" aria-label="Avatar" className="text-4xl">
                👨‍💻
              </span>
            </div>
          </div>

          <div className="flex justify-center mb-8">
            <div className="bg-[#1A1F2A] rounded-full px-4 py-2 inline-flex items-center space-x-2">
              <span className="w-2 h-2 bg-green-400 rounded-full"></span>
              <span className="text-sm text-white/80">Available for opportunities</span>
            </div>
          </div>

          <h1 className="text-5xl font-bold mb-4">
            Welcome to
            <br />
            my digital humble abode
          </h1>

          <p className="text-white/60 mb-8">
            I'm an independent designer.
            <br />
            My interest lies in brand experience, and user experience.
          </p>

          <div className="flex justify-center gap-4">
            <Button className="bg-white text-black hover:bg-white/90">🤝 Let's talk</Button>
            <Button variant="outline" className="text-white border-white/20 hover:bg-white/10">
              Get Template <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Logos Section */}
      <section className="relative z-10 px-4 py-16">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-3 md:grid-cols-7 gap-8 items-center opacity-50">
            <Image
              src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=30&width=100`}
              alt="Company logo"
              width={100}
              height={30}
              className="w-auto h-8 object-contain"
            />
            <Image
              src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=30&width=100`}
              alt="Airbnb"
              width={100}
              height={30}
              className="w-auto h-8 object-contain"
            />
            <Image
              src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=30&width=100`}
              alt="Microsoft"
              width={100}
              height={30}
              className="w-auto h-8 object-contain"
            />
            <Image
              src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=30&width=100`}
              alt="Duolingo"
              width={100}
              height={30}
              className="w-auto h-8 object-contain"
            />
            <Image
              src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=30&width=100`}
              alt="Netflix"
              width={100}
              height={30}
              className="w-auto h-8 object-contain"
            />
            <Image
              src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=30&width=100`}
              alt="Disney"
              width={100}
              height={30}
              className="w-auto h-8 object-contain"
            />
            <Image
              src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=30&width=100`}
              alt="Company logo"
              width={100}
              height={30}
              className="w-auto h-8 object-contain"
            />
          </div>
        </div>
      </section>

      {/* Case Studies Section */}
      <section className="relative z-10 px-4 py-16">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <div className="text-sm text-white/60 uppercase tracking-wider mb-4">Curated Work</div>
            <h2 className="text-4xl font-bold mb-4">Featured Case Studies</h2>
            <p className="text-white/60">Compilation of case studies that evoke my sense of pride</p>
          </div>

          <div className="space-y-8">
            {/* Airbnb Case Study */}
            <div className="bg-[#1E3A31] rounded-3xl p-8 md:p-12">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="text-white/60 uppercase text-sm">AIRBNB • 2023</div>
                    <h3 className="text-3xl font-bold">Curating AR experiences while travelling</h3>
                  </div>

                  <ul className="space-y-4">
                    <li className="flex items-center space-x-3 text-white/80">
                      <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                      <span>Onboarding increased to 12%.</span>
                    </li>
                    <li className="flex items-center space-x-3 text-white/80">
                      <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                      <span>New users signups increased by 32%.</span>
                    </li>
                    <li className="flex items-center space-x-3 text-white/80">
                      <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                      <span>Engagement increased by 20%.</span>
                    </li>
                  </ul>

                  <Button variant="outline" className="text-white border-white/20 hover:bg-white/10">
                    View Case Study <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>

                <div className="flex justify-center md:justify-end">
                  <Image
                    src={`${process.env.NEXT_PUBLIC_VERCEL_URL}/placeholder.svg?height=600&width=300`}
                    alt="Airbnb AR Experience mockup"
                    width={300}
                    height={600}
                    className="w-auto h-[500px] object-contain"
                  />
                </div>
              </div>
            </div>

            {/* Shopify Case Study */}
            <div className="bg-[#1A1F2A] rounded-3xl p-8 md:p-12">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="text-white/60 uppercase text-sm">SHOPIFY • 2023</div>
                    <h3 className="text-3xl font-bold">Building profitable dropshipping dashboard</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Decorative Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-500/20 rounded-full filter blur-3xl"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full filter blur-3xl"></div>
      </div>
    </div>
  )
}

